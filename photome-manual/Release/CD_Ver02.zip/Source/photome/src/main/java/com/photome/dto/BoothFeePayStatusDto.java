/**
 * 2013 BoothFeePayStatusDto.java Licensed to Steven J.S Min. For use this source code, you must have to get right from the author. Unless enforcement
 * is prohibited by applicable law, you may not modify, decompile, or reverse engineer Software.
 */
package com.photome.dto;

/**
 * @author Steven J.S Min
 * 
 */
public class BoothFeePayStatusDto {

	private String groupId;
	private BoothGroupDto boothGroup;
	private String month_01;
	private String month_02;
	private String month_03;
	private String month_04;
	private String month_05;
	private String month_06;
	private String month_07;
	private String month_08;
	private String month_09;
	private String month_10;
	private String month_11;
	private String month_12;
	private String month_01_status;
	private String month_02_status;
	private String month_03_status;
	private String month_04_status;
	private String month_05_status;
	private String month_06_status;
	private String month_07_status;
	private String month_08_status;
	private String month_09_status;
	private String month_10_status;
	private String month_11_status;
	private String month_12_status;
	private String month_total;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public BoothGroupDto getBoothGroup() {
		return boothGroup;
	}

	public void setBoothGroup(BoothGroupDto boothGroup) {
		this.boothGroup = boothGroup;
	}

	public String getMonth_01() {
		return month_01;
	}

	public void setMonth_01(String month_01) {
		this.month_01 = month_01;
	}

	public String getMonth_02() {
		return month_02;
	}

	public void setMonth_02(String month_02) {
		this.month_02 = month_02;
	}

	public String getMonth_03() {
		return month_03;
	}

	public void setMonth_03(String month_03) {
		this.month_03 = month_03;
	}

	public String getMonth_04() {
		return month_04;
	}

	public void setMonth_04(String month_04) {
		this.month_04 = month_04;
	}

	public String getMonth_05() {
		return month_05;
	}

	public void setMonth_05(String month_05) {
		this.month_05 = month_05;
	}

	public String getMonth_06() {
		return month_06;
	}

	public void setMonth_06(String month_06) {
		this.month_06 = month_06;
	}

	public String getMonth_07() {
		return month_07;
	}

	public void setMonth_07(String month_07) {
		this.month_07 = month_07;
	}

	public String getMonth_08() {
		return month_08;
	}

	public void setMonth_08(String month_08) {
		this.month_08 = month_08;
	}

	public String getMonth_09() {
		return month_09;
	}

	public void setMonth_09(String month_09) {
		this.month_09 = month_09;
	}

	public String getMonth_10() {
		return month_10;
	}

	public void setMonth_10(String month_10) {
		this.month_10 = month_10;
	}

	public String getMonth_11() {
		return month_11;
	}

	public void setMonth_11(String month_11) {
		this.month_11 = month_11;
	}

	public String getMonth_12() {
		return month_12;
	}

	public void setMonth_12(String month_12) {
		this.month_12 = month_12;
	}

	public String getMonth_total() {
		return month_total;
	}

	public void setMonth_total(String month_total) {
		this.month_total = month_total;
	}

	public String getMonth_01_status() {
		return month_01_status;
	}

	public void setMonth_01_status(String month_01_status) {
		this.month_01_status = month_01_status;
	}

	public String getMonth_02_status() {
		return month_02_status;
	}

	public void setMonth_02_status(String month_02_status) {
		this.month_02_status = month_02_status;
	}

	public String getMonth_03_status() {
		return month_03_status;
	}

	public void setMonth_03_status(String month_03_status) {
		this.month_03_status = month_03_status;
	}

	public String getMonth_04_status() {
		return month_04_status;
	}

	public void setMonth_04_status(String month_04_status) {
		this.month_04_status = month_04_status;
	}

	public String getMonth_05_status() {
		return month_05_status;
	}

	public void setMonth_05_status(String month_05_status) {
		this.month_05_status = month_05_status;
	}

	public String getMonth_06_status() {
		return month_06_status;
	}

	public void setMonth_06_status(String month_06_status) {
		this.month_06_status = month_06_status;
	}

	public String getMonth_07_status() {
		return month_07_status;
	}

	public void setMonth_07_status(String month_07_status) {
		this.month_07_status = month_07_status;
	}

	public String getMonth_08_status() {
		return month_08_status;
	}

	public void setMonth_08_status(String month_08_status) {
		this.month_08_status = month_08_status;
	}

	public String getMonth_09_status() {
		return month_09_status;
	}

	public void setMonth_09_status(String month_09_status) {
		this.month_09_status = month_09_status;
	}

	public String getMonth_10_status() {
		return month_10_status;
	}

	public void setMonth_10_status(String month_10_status) {
		this.month_10_status = month_10_status;
	}

	public String getMonth_11_status() {
		return month_11_status;
	}

	public void setMonth_11_status(String month_11_status) {
		this.month_11_status = month_11_status;
	}

	public String getMonth_12_status() {
		return month_12_status;
	}

	public void setMonth_12_status(String month_12_status) {
		this.month_12_status = month_12_status;
	}

}
