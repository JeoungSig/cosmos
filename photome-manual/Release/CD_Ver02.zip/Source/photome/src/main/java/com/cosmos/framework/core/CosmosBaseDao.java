/** 
 * 2013 CosmosBaseDao.java
 * Licensed to the Steven J.S Min. 
 * For use this source code, you must have to get right from the author. 
 * Unless enforcement is prohibited by applicable law, you may not modify, decompile, or reverse engineer Software.
 */

package com.cosmos.framework.core;

import org.mybatis.spring.support.SqlSessionDaoSupport;

/**
 * @author Steven J.S Min
 *
 */
public class CosmosBaseDao extends SqlSessionDaoSupport  {
	
}
