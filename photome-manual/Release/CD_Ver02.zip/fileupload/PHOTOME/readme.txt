﻿C:\Temp\patch>mysqldump -u root -p photome > photome_20130517.sql
Enter password: ********


C:\Temp\patch>mysql -u root -p photome < photome_20130517.sql
